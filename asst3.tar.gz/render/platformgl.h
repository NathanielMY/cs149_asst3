#ifndef __PLATFORM_GL_H__
#define __PLATFORM_GL_H__

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#endif

